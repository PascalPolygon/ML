Run 

python3 testTennis.py
python3 testIris.py 
python3 testIrisNoisy.py